"""
本地下载中心：aria2c JSON-RPC 后端 + 网页前端 + 给 Claude 用的 HTTP API。

    python server.py [--port 6801] [--open]

- 自动拉起/复用一个后台 aria2c（RPC 6800，带 secret，只监听 127.0.0.1）
- 网页 http://127.0.0.1:6801 实时看进度（IDM 风格）
- HuggingFace 链接自动去官方 API 取 sha256，下完自动校验
- 全程阻止系统睡眠
"""

import argparse
import ctypes
import hashlib
import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_DIR = os.path.join(os.environ.get("LOCALAPPDATA", HERE), "dlserver")
os.makedirs(STATE_DIR, exist_ok=True)
SECRET_FILE = os.path.join(STATE_DIR, "secret.txt")
JOBS_FILE = os.path.join(STATE_DIR, "jobs.json")
SESSION_FILE = os.path.join(STATE_DIR, "aria2.session")
ARIA_LOG = os.path.join(STATE_DIR, "aria2.log")

RPC_PORT = 6800
RPC_URL = f"http://127.0.0.1:{RPC_PORT}/jsonrpc"
DEFAULT_DIR = os.path.join(os.path.expanduser("~"), "Downloads")

ARIA_DEFAULTS = [
    "--continue=true",
    "--allow-overwrite=false",
    "--auto-file-renaming=false",
    "--max-connection-per-server=16",
    "--split=16",
    "--min-split-size=10M",
    "--file-allocation=falloc",
    "--max-tries=0",
    "--retry-wait=5",
    "--timeout=30",
    "--connect-timeout=30",
    "--lowest-speed-limit=10K",
    "--max-concurrent-downloads=3",
    # 默认 60 秒才刷一次 .aria2 控制文件，断电最多丢 60 秒进度（20 MB/s 就是 1.2 GB），
    # 而且改设置要靠重建任务来重新分块，控制文件太旧会导致从头下。压到 5 秒。
    "--auto-save-interval=5",
]


# ------------------------------------------------------------------ 工具

def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def keep_awake():
    """ES_CONTINUOUS | ES_SYSTEM_REQUIRED，进程退出自动恢复。"""
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    except Exception:
        pass


def port_open(port):
    with socket.socket() as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


# ------------------------------------------------------------------ 网络（梯子）

# 常见本地代理端口：clash / clash-verge / v2rayN / 通用
PROXY_PORTS = [(7890, "Clash"), (7897, "Clash Verge"), (10809, "v2rayN"),
               (10808, "v2rayN"), (1080, "SOCKS 常用"), (8080, "HTTP 常用")]


def detect_proxies():
    out = []
    for port, label in PROXY_PORTS:
        if port_open(port):
            out.append({"label": f"{label} · 127.0.0.1:{port}",
                        "value": f"http://127.0.0.1:{port}", "port": port})
    return out


def recommend_conn(size):
    """按文件大小推荐连接数。小文件开一堆线程只会增加握手开销。"""
    if not size:
        return 8
    mb = size / (1 << 20)
    if mb < 10:
        return 1
    if mb < 100:
        return 4
    if mb < 1024:
        return 8
    return 16


def get_secret():
    if os.path.exists(SECRET_FILE):
        return open(SECRET_FILE, encoding="utf-8").read().strip()
    tok = secrets.token_hex(16)
    with open(SECRET_FILE, "w", encoding="utf-8") as f:
        f.write(tok)
    return tok


SECRET = get_secret()


# ------------------------------------------------------------------ aria2 RPC

class RpcError(Exception):
    pass


def rpc(method, *params):
    body = json.dumps({
        "jsonrpc": "2.0", "id": "dl", "method": method,
        "params": [f"token:{SECRET}", *params],
    }).encode()
    req = urllib.request.Request(RPC_URL, data=body,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            out = json.load(r)
    except urllib.error.HTTPError as e:
        # aria2 把 JSON-RPC 层的错误用 HTTP 400 返回，错误详情在 body 里
        try:
            out = json.loads(e.read())
        except Exception:
            raise RpcError(f"HTTP {e.code} {e.reason}")
    if "error" in out:
        raise RpcError(out["error"].get("message", str(out["error"])))
    return out["result"]


def ensure_aria2():
    if port_open(RPC_PORT):
        try:
            rpc("aria2.getVersion")
            log("复用已在运行的 aria2 RPC")
            return
        except Exception:
            raise SystemExit(f"端口 {RPC_PORT} 被别的程序占了，先关掉它")

    args = [
        "aria2c", "--enable-rpc",
        f"--rpc-listen-port={RPC_PORT}",
        f"--rpc-secret={SECRET}",
        "--rpc-listen-all=false",
        "--rpc-allow-origin-all=true",
        f"--dir={DEFAULT_DIR}",
        f"--save-session={SESSION_FILE}",
        "--save-session-interval=20",
        f"--log={ARIA_LOG}", "--log-level=warn",
        "--console-log-level=error",
        "--daemon=false",
        *ARIA_DEFAULTS,
    ]
    if os.path.exists(SESSION_FILE):
        args.append(f"--input-file={SESSION_FILE}")

    flags = 0
    if os.name == "nt":
        flags = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=flags, close_fds=True)

    for _ in range(50):
        time.sleep(0.2)
        if port_open(RPC_PORT):
            try:
                rpc("aria2.getVersion")
                log(f"已启动 aria2c，RPC 端口 {RPC_PORT}")
                return
            except Exception:
                pass
    raise SystemExit("aria2c 起不来，检查 aria2c 是否在 PATH")


# ------------------------------------------------------------------ 任务附加信息（sha256 等）

JOBS_LOCK = threading.Lock()
if os.path.exists(JOBS_FILE):
    try:
        JOBS = json.load(open(JOBS_FILE, encoding="utf-8"))
    except Exception:
        JOBS = {}
else:
    JOBS = {}


def save_jobs():
    with JOBS_LOCK:
        tmp = JOBS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(JOBS, f, ensure_ascii=False, indent=1)
        os.replace(tmp, JOBS_FILE)


def job(gid):
    with JOBS_LOCK:
        return JOBS.setdefault(gid, {})


# ------------------------------------------------------------------ HuggingFace 官方 sha256

HF_RE = re.compile(
    r"https?://huggingface\.co/(?:(datasets)/)?([^/]+/[^/]+)/resolve/([^/]+)/(.+?)(?:\?|$)")


def hf_official_sha(url):
    """能认出来就返回 (sha256, size)，否则 (None, None)。"""
    m = HF_RE.match(url)
    if not m:
        return None, None
    is_ds, repo, _rev, path = m.groups()
    seg = "datasets" if is_ds else "models"
    path = urllib.parse.unquote(path)
    try:
        api = f"https://huggingface.co/api/{seg}/{repo}/tree/main?recursive=1"
        req = urllib.request.Request(api, headers={"User-Agent": "dlserver"})
        with urllib.request.urlopen(req, timeout=30) as r:
            tree = json.load(r)
        for e in tree:
            if e.get("path") == path and e.get("type") == "file":
                lfs = e.get("lfs") or {}
                return lfs.get("oid"), e.get("size")
    except Exception as e:
        log(f"取 HF 哈希失败: {e}")
    return None, None


def attach_hf_sha(gid, url):
    sha, size = hf_official_sha(url)
    if sha:
        j = job(gid)
        j["sha256_expected"] = sha
        j["official_size"] = size
        j["verify"] = "pending"
        save_jobs()
        log(f"{gid} 官方 sha256 {sha[:16]}…")


# ------------------------------------------------------------------ 下完自动校验

VERIFYING = set()


def verify_worker(gid, path, expected):
    VERIFYING.add(gid)
    j = job(gid)
    j["verify"] = "running"
    j["verify_progress"] = 0.0
    save_jobs()
    try:
        total = os.path.getsize(path)
        h = hashlib.sha256()
        done = 0
        with open(path, "rb") as f:
            while True:
                b = f.read(8 << 20)
                if not b:
                    break
                h.update(b)
                done += len(b)
                j["verify_progress"] = done / total if total else 1.0
        got = h.hexdigest()
        j["sha256_actual"] = got
        j["verify"] = "ok" if got == expected else "bad"
        log(f"{gid} 校验 {j['verify']}")
    except Exception as e:
        j["verify"] = "error"
        j["verify_error"] = str(e)
    finally:
        j["verify_progress"] = 1.0
        VERIFYING.discard(gid)
        save_jobs()


def watcher():
    """盯着已完成的任务，该校验的校验。"""
    while True:
        try:
            for st in rpc("aria2.tellStopped", 0, 50):
                gid = st["gid"]
                j = job(gid)
                if st.get("status") != "complete":
                    continue
                exp = j.get("sha256_expected")
                if not exp or j.get("verify") in ("ok", "bad", "running", "error"):
                    continue
                files = st.get("files") or []
                if not files:
                    continue
                p = files[0].get("path")
                if p and os.path.exists(p) and gid not in VERIFYING:
                    threading.Thread(target=verify_worker, args=(gid, p, exp),
                                     daemon=True).start()
        except Exception:
            pass
        time.sleep(3)


# ------------------------------------------------------------------ 聚合状态

FIELDS = ["gid", "status", "totalLength", "completedLength", "downloadSpeed",
          "connections", "dir", "files", "errorMessage", "bitfield",
          "numPieces", "pieceLength"]


def describe(st):
    gid = st["gid"]
    j = dict(job(gid))
    files = st.get("files") or []
    path = files[0].get("path") if files else ""
    uris = (files[0].get("uris") or []) if files else []
    uri = j.get("url") or (uris[0].get("uri") if uris else "")
    name = os.path.basename(path) if path else (
        os.path.basename(urllib.parse.urlparse(uri).path) or "(未知)")

    total = int(st.get("totalLength") or 0)
    done = int(st.get("completedLength") or 0)
    speed = int(st.get("downloadSpeed") or 0)

    servers = []
    if st.get("status") == "active":
        try:
            for f in rpc("aria2.getServers", gid):
                for s in f.get("servers", []):
                    servers.append({
                        "uri": s.get("currentUri", ""),
                        "speed": int(s.get("downloadSpeed") or 0),
                    })
        except Exception:
            pass

    return {
        "gid": gid,
        "name": name,
        "url": uri,
        "path": path,
        "dir": st.get("dir", ""),
        "status": st.get("status"),
        "total": total,
        "done": done,
        "speed": speed,
        "connections": int(st.get("connections") or 0),
        "eta": int((total - done) / speed) if speed > 0 and total > done else None,
        "resumable": True,
        "bitfield": st.get("bitfield", ""),
        "numPieces": int(st.get("numPieces") or 0),
        "error": st.get("errorMessage", ""),
        "servers": sorted(servers, key=lambda x: -x["speed"])[:32],
        "sha256_expected": j.get("sha256_expected"),
        "sha256_actual": j.get("sha256_actual"),
        "verify": j.get("verify"),
        "verify_progress": j.get("verify_progress"),
        "added": j.get("added"),
        "proxy": j.get("proxy", ""),
        "conn_set": j.get("conn"),
        "conn_auto": j.get("conn_auto", False),
    }


def snapshot():
    out = []
    try:
        for st in rpc("aria2.tellActive", FIELDS):
            out.append(describe(st))
        for st in rpc("aria2.tellWaiting", 0, 50, FIELDS):
            out.append(describe(st))
        for st in rpc("aria2.tellStopped", 0, 50, FIELDS):
            out.append(describe(st))
    except Exception as e:
        return {"error": str(e), "items": []}
    g = {}
    try:
        g = rpc("aria2.getGlobalStat")
    except Exception:
        pass
    return {
        "items": out,
        "global": {
            "speed": int(g.get("downloadSpeed", 0) or 0),
            "active": int(g.get("numActive", 0) or 0),
            "waiting": int(g.get("numWaiting", 0) or 0),
        },
        "ts": time.time(),
    }


class AddError(Exception):
    pass


def _opener(proxy):
    if proxy:
        return urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
    return urllib.request.build_opener(urllib.request.ProxyHandler({}))


def preflight(url, proxy=None):
    """加队列前先探一下，坏链接立刻报错，别等排到才发现。返回服务器给的文件大小。"""
    req = urllib.request.Request(url, method="HEAD",
                                 headers={"User-Agent": "Mozilla/5.0 dlserver"})
    try:
        with _opener(proxy).open(req, timeout=20) as r:
            return int(r.headers.get("Content-Length") or 0)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise AddError(f"{e.code} 没权限——这个仓库可能需要登录/同意协议")
        if e.code == 404:
            raise AddError("404 链接不存在，检查一下路径拼写")
        if 400 <= e.code < 500:
            raise AddError(f"{e.code} {e.reason}")
    except Exception:
        pass  # HEAD 不支持 / 网络抖动，别拦着，交给 aria2 重试
    return 0


def target_name(url, name=None):
    """HF 会 302 到 xet CDN，那边路径末段是哈希串；不指定 out 的话文件名就毁了。"""
    if name:
        return name
    return os.path.basename(urllib.parse.unquote(
        urllib.parse.urlparse(url).path).rstrip("/")) or None


def probe(url, proxy=None, name=None):
    """给界面用：先量一下大小，好显示推荐线程数。"""
    size = preflight(url, proxy)
    return {
        "name": target_name(url, name) or "(未知)",
        "size": size,
        "recommend": recommend_conn(size),
        "proxy": proxy or "",
    }


def add_download(url, directory=None, name=None, sha256=None, conn=0, proxy=None):
    """conn=0 表示按文件大小自动推荐。proxy=None/'' 表示直连。"""
    directory = directory or DEFAULT_DIR
    os.makedirs(directory, exist_ok=True)
    name = target_name(url, name)

    remote_size = preflight(url, proxy)

    if name:
        target = os.path.join(directory, name)
        if os.path.exists(target) and not os.path.exists(target + ".aria2"):
            sz = os.path.getsize(target)
            if remote_size and sz == remote_size:
                raise AddError(f"这个文件已经下好了（{sz/2**30:.2f} GB）：{target}")
            raise AddError(
                f"目标目录已有同名文件（{sz/2**30:.2f} GB）：{target}\n"
                "换个名字或先把旧的删掉/挪走")

    auto = not conn
    if auto:
        conn = recommend_conn(remote_size)

    opts = {
        "dir": directory,
        "max-connection-per-server": str(conn),
        "split": str(conn),
        "all-proxy": proxy or "",   # 空串 = 直连，覆盖掉全局设置
    }
    if name:
        opts["out"] = name
    gid = rpc("aria2.addUri", [url], opts)
    j = job(gid)
    j.update({"url": url, "added": time.time(), "conn": conn,
              "conn_auto": auto, "proxy": proxy or ""})
    if sha256:
        j["sha256_expected"] = sha256.lower()
        j["verify"] = "pending"
    save_jobs()
    if not sha256:
        threading.Thread(target=attach_hf_sha, args=(gid, url), daemon=True).start()
    log(f"已加入 {url} -> {directory}  [{conn} 线程{'(自动)' if auto else ''}, "
        f"{proxy or '直连'}]")
    return gid


def retune(gid, proxy=None, conn=None):
    """
    改网络 / 分块数。

    不能用 changeOption：aria2 从 pause 恢复时不会重新切分剩余部分，
    实测续传后只剩 2 条连接、速度掉到 1/10。必须销毁任务重建，
    靠磁盘上的 .aria2 控制文件从断点续，这样才会按新分块数重新切。
    """
    st = rpc("aria2.tellStatus", gid,
             ["status", "files", "dir", "completedLength", "totalLength"])
    status = st.get("status")
    if status in ("complete", "error", "removed"):
        raise AddError("这个任务已经结束了，改设置没用")

    j = dict(job(gid))
    files = st.get("files") or []
    if not files:
        raise AddError("拿不到这个任务的文件信息")
    path = files[0].get("path") or ""
    uris = files[0].get("uris") or []
    url = j.get("url") or (uris[0].get("uri") if uris else "")
    if not url:
        raise AddError("拿不到原始链接，没法重建任务")
    directory = st.get("dir") or os.path.dirname(path)
    name = os.path.basename(path) or target_name(url)
    before = int(st.get("completedLength") or 0)

    new_proxy = (j.get("proxy", "") if proxy is None else (proxy or ""))
    new_conn = int(conn) if conn else int(j.get("conn") or 16)

    # 暂停并给 aria2 一点时间把控制文件刷到磁盘（auto-save-interval=5）
    if status == "active":
        rpc("aria2.pause", gid)
        for _ in range(30):
            time.sleep(0.2)
            if rpc("aria2.tellStatus", gid, ["status"]).get("status") != "active":
                break
    time.sleep(1.2)

    ctl = os.path.join(directory, name + ".aria2")
    resumable = os.path.exists(ctl)

    for m in ("aria2.remove", "aria2.removeDownloadResult"):
        try:
            rpc(m, gid)
        except RpcError:
            pass

    new_gid = rpc("aria2.addUri", [url], {
        "dir": directory,
        "out": name,
        "split": str(new_conn),
        "max-connection-per-server": str(new_conn),
        "all-proxy": new_proxy,
    })
    with JOBS_LOCK:
        JOBS.pop(gid, None)
        JOBS[new_gid] = {**j, "conn": new_conn, "proxy": new_proxy,
                         "conn_auto": False if conn else j.get("conn_auto", False)}
    save_jobs()

    log(f"{gid} -> {new_gid}  [{new_conn} 块, {new_proxy or '直连'}]  "
        f"断点 {before/2**20:.1f} MB{'' if resumable else '（无控制文件，可能重下）'}")
    return {"gid": new_gid, "conn": new_conn, "proxy": new_proxy,
            "resumed": resumable, "resume_from": before}


# ------------------------------------------------------------------ HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        if p.path in ("/", "/index.html"):
            try:
                html = open(os.path.join(HERE, "index.html"), encoding="utf-8").read()
            except OSError:
                return self._send(500, "index.html 丢了", "text/plain; charset=utf-8")
            return self._send(200, html, "text/html; charset=utf-8")
        if p.path == "/api/state":
            return self._send(200, snapshot())
        if p.path == "/api/dirs":
            return self._send(200, PRESET_DIRS)
        if p.path == "/api/net":
            return self._send(200, {"detected": detect_proxies()})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        p = urllib.parse.urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._send(400, {"error": "bad json"})
        try:
            if p.path == "/api/add":
                urls = [u.strip() for u in
                        (data.get("urls") or ([data["url"]] if data.get("url") else []))
                        if u.strip()]
                gids, errors = [], []
                for u in urls:
                    try:
                        gids.append(add_download(
                            u, data.get("dir"),
                            data.get("name") if len(urls) == 1 else None,
                            data.get("sha256") if len(urls) == 1 else None,
                            int(data.get("conn") or 0),
                            data.get("proxy") or None))
                    except AddError as e:
                        errors.append(f"{os.path.basename(urllib.parse.urlparse(u).path)}: {e}")
                    except Exception as e:
                        errors.append(f"{u}: {e}")
                out = {"gids": gids}
                if errors:
                    out["error"] = "\n".join(errors)
                return self._send(200 if gids else 400, out)
            if p.path == "/api/pause":
                return self._send(200, {"ok": rpc("aria2.pause", data["gid"])})
            if p.path == "/api/unpause":
                return self._send(200, {"ok": rpc("aria2.unpause", data["gid"])})
            if p.path == "/api/remove":
                gid = data["gid"]
                try:
                    rpc("aria2.remove", gid)
                except RpcError:
                    pass
                try:
                    rpc("aria2.removeDownloadResult", gid)
                except RpcError:
                    pass
                with JOBS_LOCK:
                    JOBS.pop(gid, None)
                save_jobs()
                return self._send(200, {"ok": True})
            if p.path == "/api/clear":
                try:
                    rpc("aria2.purgeDownloadResult")
                except RpcError:
                    pass
                return self._send(200, {"ok": True})
            if p.path == "/api/verify":
                gid = data["gid"]
                j = job(gid)
                exp = (data.get("sha256") or j.get("sha256_expected") or "").lower()
                st = rpc("aria2.tellStatus", gid, ["files"])
                path = st["files"][0]["path"]
                if not exp:
                    return self._send(400, {"error": "没有可比对的 sha256"})
                j["sha256_expected"] = exp
                j["verify"] = "pending"
                save_jobs()
                threading.Thread(target=verify_worker, args=(gid, path, exp),
                                 daemon=True).start()
                return self._send(200, {"ok": True})
            if p.path == "/api/limit":
                rpc("aria2.changeGlobalOption",
                    {"max-overall-download-limit": str(data.get("limit", "0"))})
                return self._send(200, {"ok": True})
            if p.path == "/api/probe":
                try:
                    return self._send(200, probe(data["url"].strip(),
                                                 data.get("proxy") or None))
                except AddError as e:
                    return self._send(400, {"error": str(e)})
            if p.path == "/api/retune":
                return self._send(200, retune(data["gid"],
                                              data.get("proxy"),
                                              int(data["conn"]) if data.get("conn") else None))
        except KeyError as e:
            return self._send(400, {"error": f"缺参数 {e}"})
        except Exception as e:
            return self._send(500, {"error": str(e)})
        return self._send(404, {"error": "not found"})


PRESET_DIRS = [
    {"label": "下载", "path": DEFAULT_DIR},
    {"label": "桌面", "path": os.path.join(os.path.expanduser("~"), "Desktop")},
    {"label": "文档", "path": os.path.join(os.path.expanduser("~"), "Documents")},
    {"label": "视频", "path": os.path.join(os.path.expanduser("~"), "Videos")},
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=6801)
    ap.add_argument("--open", action="store_true")
    ap.add_argument("--add", action="append", default=[], help="启动时直接加一个 URL")
    ap.add_argument("--dir", default=None)
    a = ap.parse_args()

    keep_awake()
    ensure_aria2()
    threading.Thread(target=watcher, daemon=True).start()

    for u in a.add:
        try:
            add_download(u, a.dir)
        except Exception as e:
            log(f"加任务失败 {u}: {e}")

    if port_open(a.port):
        log(f"UI 已经在 http://127.0.0.1:{a.port} 跑着了，本进程退出")
        if a.open:
            webbrowser.open(f"http://127.0.0.1:{a.port}/")
        return

    srv = ThreadingHTTPServer(("127.0.0.1", a.port), Handler)
    log(f"下载中心 -> http://127.0.0.1:{a.port}")
    if a.open:
        threading.Timer(0.6, webbrowser.open,
                        args=[f"http://127.0.0.1:{a.port}/"]).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log("bye")


if __name__ == "__main__":
    main()
