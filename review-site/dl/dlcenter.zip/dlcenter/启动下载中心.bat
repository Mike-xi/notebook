@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem 优先用 pythonw（不弹黑窗），没有就退回 python / py
where pythonw >nul 2>nul && (
  start "" pythonw "%~dp0server.py" --port 6801 --open
  exit /b
)
where python >nul 2>nul && (
  python "%~dp0server.py" --port 6801 --open
  exit /b
)
where py >nul 2>nul && (
  py -3 "%~dp0server.py" --port 6801 --open
  exit /b
)

echo.
echo   没找到 Python。先装一个 Python 3（勾上 Add to PATH），再双击本文件。
echo   下载： https://www.python.org/downloads/
echo.
pause
