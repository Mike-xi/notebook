# 下载中心（本地版）

多线程下载器：aria2c 干活，网页当界面，HuggingFace 链接下完自动校验 sha256。
全程阻止系统睡眠，关掉网页也不影响下载。

## 要先装两样东西

1. **Python 3**（3.8 以上都行）—— https://www.python.org/downloads/
   安装时记得勾上 *Add python.exe to PATH*。
2. **aria2** —— Windows 上一句话搞定：

   ```powershell
   winget install aria2.aria2
   ```

   装完新开一个终端，`aria2c -v` 能打印版本就算好了。
   （也可以去 https://github.com/aria2/aria2/releases 下 zip，解压后把目录加进 PATH。）

## 用法

双击 **启动下载中心.bat**，浏览器会自己打开 <http://127.0.0.1:6801>。
把直链粘进输入框 → 选保存目录 → 开始。

- 网页里能看实时速度、进度、剩余时间，可暂停/继续/删除。
- 想开机就在后台待命：右键 `启动下载中心.bat` → 创建快捷方式 → 把快捷方式丢进
  `shell:startup`（Win+R 输这个就能打开启动文件夹）。
- 端口被占了就改一下 bat 里的 `--port`。

## 也能给脚本 / AI 调用

服务本身就是一个 HTTP API，跑起来之后：

```bash
# 加任务
curl -X POST http://127.0.0.1:6801/api/add \
  -H "Content-Type: application/json" \
  -d "{\"url\":\"https://example.com/big.zip\",\"dir\":\"D:/Downloads\"}"

# 看状态
curl http://127.0.0.1:6801/api/state
```

其它端点：`/api/probe`（探测文件名大小）、`/api/pause`、`/api/unpause`、
`/api/remove`、`/api/verify`（校验 sha256）、`/api/limit`（全局限速）、
`/api/retune`（改线程数/代理，会重建任务）。

## 和网站上的「云端转存」有什么区别

| | 本地版 | 云端转存 |
|---|---|---|
| 下到哪 | 直接落到你这台电脑 | 落到网站云盘，之后再从云盘取 |
| 速度 | 吃你自己的宽带，16 线程 | 走 Cloudflare 骨干，源站慢也不占你带宽 |
| 需要开着 | 电脑得开机 | 关掉页面照跑 |
| 断点续传 | 有 | 没有（超时会重来） |
| 大文件 | 不限 | 单个有上限 |

几个 G 的大件用本地版；人不在电脑前、或者源站从校园网连不动的，用云端转存。
